@extends('backend.layouts.master')
@section('main_content')
    <div class="row">
        <div class="col-lg-12">
            <div class="card-style">
                
            </div>
        </div>
    </div>
@endsection
