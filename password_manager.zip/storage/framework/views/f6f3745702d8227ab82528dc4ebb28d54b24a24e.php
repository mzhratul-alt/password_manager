
<?php $__env->startSection('main_content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card-style">
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Web\Laravel\password_manager\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>