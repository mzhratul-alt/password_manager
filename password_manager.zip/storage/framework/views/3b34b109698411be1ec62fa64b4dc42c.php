
<?php $__env->startSection('main_content'); ?>
    <div class="row">
        <div class="col-lg-7">
            <div class="card-style mb-30">
                <div class="mb-20">
                    <h6 class="mb-10">Role List</h6>
                    <p class="text-sm mb-20">
                        For basic styling—light padding and only horizontal
                        dividers—use the class table.
                    </p>
                </div>
                <div class="table-wrapper table-responsive text-center">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>
                                    #
                                </th>
                                <th>
                                    <h6>Name</h6>
                                </th>
                                <th>
                                    <h6>Action</h6>
                                </th>
                            </tr>
                            <!-- end table row-->
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $allRole; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <?php echo e($loop->index + 1); ?>

                                    </td>
                                    <td class="min-width">
                                        <p><?php echo e($role->name); ?></p>
                                    </td>
                                    <td>
                                        <div class="action justify-content-center">
                                            <a href="<?php echo e(route('admin.role.show', $role->id)); ?>" class="p-2 text-info">
                                                <i class="lni lni-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('admin.role.delete', $role->id)); ?>" class="p-2 text-danger"
                                                onclick="event.preventDefault();document.querySelector('#roleDeleteForm').submit()">
                                                <i class="lni lni-trash-can"></i>
                                            </a>
                                            <form id="roleDeleteForm" action="<?php echo e(route('admin.role.delete', $role->id)); ?>"
                                                method="POST">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <!-- end table row -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3">
                                        <div class="alert-box danger-alert">
                                            <div class="alert">
                                                <h4 class="alert-heading">No Role Found!</h4>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <!-- end table -->
                </div>

            </div>
            <!-- end card -->
        </div>
        <!-- end col -->
        <div class="col-lg-5">
            <div class="card-style">
                <div class="mb-20">
                    <h6 class="mb-10">Create New Role</h6>
                    <p class="text-sm mb-20">
                        For basic styling—light padding and only horizontal
                        dividers—use the class table.
                    </p>
                </div>
                <form class="row" action="<?php echo e(route('admin.role.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="col-lg-12">
                        <div class="input-style-3">
                            <input type="text" name="name" placeholder="Enter Roll Name">
                            <span class="icon"><i class="lni lni-checkmark-circle"></i></span>
                        </div>
                    </div>
                    
                    <div class="col-lg-12">
                        <button type="submit" class="w-100 btn-sm main-btn primary-btn rounded-md btn-hover">
                            Add New Role
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Web\Laravel\password_manager\resources\views/backend/roles/roleIndex.blade.php ENDPATH**/ ?>