
<?php $__env->startSection('main_content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card-style mb-30">
                <div class="d-flex justify-content-between align-items-center mb-20">
                    <div>
                        <h6 class="mb-10">Role Edit</h6>
                        <p class="text-sm mb-20">
                            For basic styling—light padding and only horizontal
                            dividers—use the class table.
                        </p>
                    </div>
                    <div>
                        <a href="<?php echo e(route('admin.role.index')); ?>" class="px-5 btn-sm main-btn warning-btn rounded-md btn-hover">
                            View All Role
                        </a>
                        <button type="submit" onclick="$('#role_permission_update_form').submit()" class="px-5 btn-sm main-btn primary-btn rounded-md btn-hover">
                            Update Role
                        </button>
                    </div>
                </div>

                <form id="role_permission_update_form" class="row" action="<?php echo e(route('admin.role.update', $role->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="col-lg-12">
                        <div class="input-style-3">
                            <input type="text" name="name" value="<?php echo e($role->name); ?>" placeholder="Enter Roll Name">
                            <span class="icon"><i class="lni lni-checkmark-circle"></i></span>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="form-check form-switch my-2">
                            <input type="checkbox" class="form-check-input" role="switch" id="cbx_select_all">
                            <label for="cbx_select_all" class="form-check-label text-capitalize">All Permission</label>
                        </div>
                        <div class="row">
                            <?php $__currentLoopData = $allPermission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission_group_name => $permission_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 mb-3">
                                    <div class="card">
                                        <div class="card-header">
                                            <div class="form-check form-switch">
                                                <input class="form-check-input cbx_group" type="checkbox" role="switch"
                                                    id="cbx_group_<?php echo e($permission_group_name); ?>"
                                                    value="<?php echo e($permission_group_name); ?>">
                                                <label class="form-check-label text-capitalize"
                                                    for="cbx_group_<?php echo e($permission_group_name); ?>">
                                                    <?php echo e($permission_group_name); ?>

                                                </label>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <?php $__currentLoopData = $permission_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="form-check form-switch">
                                                    <input
                                                        class="form-check-input cbx_item cbx_group_<?php echo e($permission_group_name); ?>"
                                                        type="checkbox" role="switch"
                                                        id="<?php echo e($permission_group_name . $permission->id); ?>"
                                                        data-group="<?php echo e($permission_group_name); ?>" name="permissions[]"
                                                        value="<?php echo e($permission->id); ?>"
                                                        <?php echo e($role->hasPermissionTo($permission->name) ? 'checked' : ''); ?>>
                                                    <label class="form-check-label"
                                                        for="<?php echo e($permission_group_name . $permission->id); ?>">
                                                        <?php echo e($permission->name); ?>

                                                    </label>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </form>

            </div>
            <!-- end card -->
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('child_scripts'); ?>
    <script>
        $(function() {
            //Select All cbx
            $("#cbx_select_all").on("change", function() {
                if ($("#cbx_select_all").is(":checked")) {
                    $(".cbx_item, .cbx_group").prop("checked", true);
                } else {
                    $(".cbx_item, .cbx_group").prop("checked", false);
                }
            });

            //Select Group cbx
            $(".cbx_group").on("change", function() {
                var groupName = $(this).val();

                if ($("#cbx_group_" + groupName).is(":checked")) {
                    $(".cbx_group_" + groupName).prop("checked", true);
                } else {
                    $(".cbx_group_" + groupName).prop("checked", false);
                }

                checkAllState();
            });

            // Select cbx Item

            $(".cbx_item").on("change", function() {
                var groupName = $(this).data("group");
                var total_group_cbx = $(".cbx_group_" + groupName).length;
                var total_selected_group_cbx = $(
                    ".cbx_group_" + groupName + ":checked"
                ).length;

                if (total_group_cbx == total_selected_group_cbx) {
                    $("#cbx_group_" + groupName).prop("checked", true);
                } else {
                    $("#cbx_group_" + groupName).prop("checked", false);
                }

                checkAllState();
            });

            function checkAllState() {
                var all_cbx = $(".cbx_item").length + $(".cbx_group").length,
                    all_selected_cbx =
                    $(".cbx_item:checked").length + $(".cbx_group:checked").length;
                if (all_cbx == all_selected_cbx) {
                    $("#cbx_select_all").prop("checked", true);
                } else {
                    $("#cbx_select_all").prop("checked", false);
                }
            }

            $(window).on("load", function() {
                $(".cbx_item").each(function() {
                    var groupName = $(this).data("group");
                    var total_group_cbx = $(".cbx_group_" + groupName).length;
                    var total_selected_group_cbx = $(
                        ".cbx_group_" + groupName + ":checked"
                    ).length;

                    if (total_group_cbx == total_selected_group_cbx) {
                        $("#cbx_group_" + groupName).prop("checked", true);
                    } else {
                        $("#cbx_group_" + groupName).prop("checked", false);
                    }
                });
                checkAllState();
            });
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Web\Laravel\password_manager\resources\views/backend/roles/roleShow.blade.php ENDPATH**/ ?>