<?php $__env->startSection('main_content'); ?>
    <div class="row">
        <div class="col-lg-12 d-flex justify-content-between align-items-center">
            <h4 class="mb-4"><?php echo e($hash->name); ?> Information</h4>
            <a class="main-btn danger-btn rounded-md btn-hover mb-4" href="<?php echo e(url()->previous()); ?>">Back</a>
        </div>
        <div class="col-lg-4">
            <div class="card-style mb-30">
                <div class="card-content">
                    <h3 class="text-bold mb-10">Site Short Code</h3>
                    <h6 class="mb-10"><?php echo e($hash->short_code); ?></h6>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card-style mb-30">
                <div class="card-content">
                    <h3 class="text-bold mb-10">Site Creation Date</h3>
                    <h6 class="mb-10"><?php echo e($hash->creation_date); ?></h6>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card-style mb-30">
                <div class="card-content">
                    <h3 class="text-bold mb-10">Remark</h3>
                    <h6 class="mb-10"><?php echo e($hash->remark); ?></h6>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="card-style mb-30">
                <div class="card-content">
                    <h3 class="text-bold mb-10">Site Hash</h3>
                    <div class="input-style-3">
                        <input type="password" id="generated_hash" name="hash" placeholder="Hash (Readonly)"
                            value="<?php echo e(Crypt::decryptString($hash->hash)); ?>" readonly disabled>
                        <span class="icon"><i class="lni lni-checkmark-circle"></i></span>
                    </div>
                    <div class="input-style-3 d-flex">
                        <input type="text" id="password_for_hash" placeholder="Hash Password">
                        <button class="main-btn primary-btn rounded-md btn-hover ms-4" type="button" onclick="decrypt()">
                            Copy
                        </button>
                        <span class="icon"><i class="lni lni-checkmark-circle"></i></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('child_scripts'); ?>
    <script src="<?php echo e(asset('assets/js/crypto.js')); ?>"></script>
    <script>
        //Code for decrypt
        function decrypt() {
            var text = document.getElementById('generated_hash').value
            var pass = document.getElementById('password_for_hash').value

            if (text.trim() == '' || pass.trim() == '') {
                alert('Input you text & password.')
            } else {
                var decryptedBytes = CryptoJS.AES.decrypt(text, pass);
                var plaintext = decryptedBytes.toString(CryptoJS.enc.Utf8);

                navigator.clipboard.writeText(plaintext)
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Web\Laravel\password_manager\resources\views/backend/hash/hashShow.blade.php ENDPATH**/ ?>